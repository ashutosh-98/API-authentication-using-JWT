const keys = {
    jwtSecret: "65C36BBDC97B833EBC1EBBFAA5E49",
    db : {
        // dbUrl : "mongodb+srv://prashant:Zuo8asm9gWmC1vUt@cluster0.snxuq.mongodb.net/linrary?retryWrites=true&w=majority",
        dbUrl : "mongodb://localhost:27017/?readPreference=primary&appname=MongoDB%20Compass%20Community&ssl=false",
        dbName : "slDbMean"    
    }
}

module.exports = keys;